package com.nhacnho

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class Rem(val id: String, var name: String, var h: Int, var m: Int, var emoji: String, var phrases: String, var every: Int, var on: Boolean)

object Store {
    fun load(c: Context): MutableList<Rem> {
        val s = c.getSharedPreferences("n", 0).getString("l", null)
            ?: return mutableListOf(
                Rem("1", "Rửa bát", 20, 0, "🐱", "Ê, đi rửa bát đi!\nĐể lâu bát thiu rồi đó!\nBát đang khóc kìa 😭", 6, true),
                Rem("2", "Đi ngủ", 23, 0, "🐻", "Đến giờ đi ngủ rồi!\nĐặt điện thoại xuống ngay!\nNgủ đi mà, năn nỉ đó 🥺", 6, true))
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Rem(o.getString("id"), o.getString("n"), o.getInt("h"), o.getInt("m"), o.getString("e"), o.getString("p"), o.getInt("s"), o.getBoolean("o"))
        }
    }
    fun save(c: Context, l: List<Rem>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("h", it.h).put("m", it.m).put("e", it.emoji).put("p", it.phrases).put("s", it.every).put("o", it.on)) }
        c.getSharedPreferences("n", 0).edit().putString("l", a.toString()).apply()
    }
}

object Sched {
    private fun pi(c: Context, r: Rem, snz: Boolean): PendingIntent {
        val i = Intent(c, AlarmRx::class.java).putExtra("id", r.id).putExtra("snz", snz)
        return PendingIntent.getBroadcast(c, r.id.hashCode() * 2 + if (snz) 1 else 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun set(c: Context, r: Rem, at: Long, snz: Boolean) {
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, r, snz))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, r, snz))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, r, snz))
        }
    }
    fun cancel(c: Context, r: Rem) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, r, false))
    fun next(r: Rem): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, r.h); c.set(Calendar.MINUTE, r.m); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 30000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }
    fun all(c: Context) = Store.load(c).forEach { if (it.on) set(c, it, next(it), false) }
}

class AlarmRx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val r = Store.load(c).find { it.id == i.getStringExtra("id") } ?: return
        if (!r.on) return
        if (!i.getBooleanExtra("snz", false)) Sched.set(c, r, Sched.next(r), false)
        c.startForegroundService(Intent(c, OverlaySvc::class.java).putExtra("id", r.id))
    }
}

class BootRx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) = Sched.all(c)
}

class OverlaySvc : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: View? = null
    private var tone: ToneGenerator? = null
    private var anim: ObjectAnimator? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("n", "Nhắc nhở", NotificationManager.IMPORTANCE_LOW))
        val nt = Notification.Builder(this, "n").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Đang nhắc nhở").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, nt, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, nt)
        val r = Store.load(this).find { it.id == i?.getStringExtra("id") }
        if (r == null || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        show(r)
        return START_NOT_STICKY
    }

    private fun show(r: Rem) {
        hide()
        val d = resources.displayMetrics.density
        val ph = r.phrases.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(r.name + "!") }
        val em = TextView(this).apply { text = r.emoji; textSize = 120f; gravity = Gravity.CENTER }
        val nm = TextView(this).apply { text = r.name; textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFF2A0F00.toInt()) }
        val bub = TextView(this).apply {
            textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(0xFF1D1A4D.toInt())
            setPadding((20 * d).toInt(), (16 * d).toInt(), (20 * d).toInt(), (16 * d).toInt())
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 26 * d }
        }
        fun button(t: String, big: Boolean, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; textSize = if (big) 22f else 16f; setOnClickListener { f() } }
        val ok = button("Xong rồi!", true) { stopSelf() }
        val sn = button("Hoãn 5 phút", false) { Sched.set(this, r, System.currentTimeMillis() + 300000, true); stopSelf() }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((24 * d).toInt(), (60 * d).toInt(), (24 * d).toInt(), (40 * d).toInt())
            addView(em); addView(nm)
            addView(bub, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, (16 * d).toInt(), 0, (24 * d).toInt()) })
            addView(ok); addView(sn)
        }
        val rt = FrameLayout(this).apply { addView(col, FrameLayout.LayoutParams(-1, -1)) }
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE)
        wm = getSystemService(WindowManager::class.java)
        wm?.addView(rt, lp); root = rt
        anim = ObjectAnimator.ofFloat(em, "translationY", 0f, -40 * d).apply { duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() }
        tone = try { ToneGenerator(AudioManager.STREAM_ALARM, 100) } catch (e: Exception) { null }
        try { getSystemService(PowerManager::class.java).newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "nn:w").acquire(10000) } catch (e: Exception) {}
        var n = 0
        val tick = object : Runnable {
            override fun run() {
                bub.text = ph[n % ph.size]
                rt.setBackgroundColor(ArgbEvaluator().evaluate(minOf(n / 8f, 1f), 0xFFFFD23F.toInt(), 0xFFFF3B5C.toInt()) as Int)
                n++
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
                try { getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)) } catch (e: Exception) {}
                h.postDelayed(this, r.every * 1000L)
            }
        }
        h.post(tick)
    }

    private fun hide() {
        h.removeCallbacksAndMessages(null); anim?.cancel(); anim = null
        root?.let { try { wm?.removeView(it) } catch (e: Exception) {} }; root = null
        tone?.release(); tone = null
    }

    override fun onDestroy() { hide(); super.onDestroy() }
}

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private var items = mutableListOf<Rem>()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    private fun pkg() = Uri.parse("package:$packageName")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (40 * d).toInt(), (16 * d).toInt(), (24 * d).toInt())
        }
        root.addView(TextView(this).apply { text = "Nhắc Nhở Cà Khịa"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(btn("1. Cấp quyền hiện trên app khác") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg())) })
        root.addView(btn("2. Cho phép báo thức chính xác") { if (Build.VERSION.SDK_INT >= 31) runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg())) } })
        root.addView(btn("3. Tắt tối ưu pin cho app") { runCatching { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg())) } })
        root.addView(btn("Thử ngay") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Làm bước 1 trước nhé", Toast.LENGTH_LONG).show()
            else items.firstOrNull()?.let { startForegroundService(Intent(this, OverlaySvc::class.java).putExtra("id", it.id)) }
        })
        root.addView(list)
        root.addView(btn("+ Thêm lời nhắc") { edit(null) })
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        items = Store.load(this); Sched.all(this); draw()
    }

    private fun draw() {
        list.removeAllViews()
        items.forEach { r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 24, 0, 24) }
            row.addView(TextView(this).apply {
                text = "${r.emoji}  ${r.name}\n%02d:%02d".format(r.h, r.m); textSize = 20f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setOnClickListener { edit(r) }
            })
            row.addView(Switch(this).apply {
                isChecked = r.on
                setOnCheckedChangeListener { _, v ->
                    r.on = v; Store.save(this@MainActivity, items)
                    if (v) Sched.set(this@MainActivity, r, Sched.next(r), false) else Sched.cancel(this@MainActivity, r)
                }
            })
            list.addView(row)
        }
    }

    private fun edit(old: Rem?) {
        val r = old ?: Rem("r" + System.currentTimeMillis(), "", 21, 0, "🐱", "", 6, true)
        var h = r.h; var m = r.m
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }
        fun et(hint: String, t: String, multi: Boolean = false) = EditText(this).apply {
            setHint(hint); setText(t)
            if (multi) { setSingleLine(false); minLines = 4 }
        }
        val n = et("Tên việc", r.name)
        val e = et("Nhân vật (gõ 1 emoji)", r.emoji)
        val p = et("Mỗi dòng 1 câu nhân vật nói", r.phrases, true)
        val s = et("Đổi câu sau (giây)", r.every.toString()); s.inputType = InputType.TYPE_CLASS_NUMBER
        val tb = btn("Giờ: %02d:%02d".format(h, m)) {}
        tb.setOnClickListener { TimePickerDialog(this, { _, hh, mm -> h = hh; m = mm; tb.text = "Giờ: %02d:%02d".format(h, m) }, h, m, true).show() }
        listOf<View>(n, tb, e, p, s).forEach { v.addView(it) }
        AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(v) })
            .setPositiveButton("Lưu") { _, _ ->
                r.name = n.text.toString().ifBlank { "Nhắc nhở" }; r.h = h; r.m = m
                r.emoji = e.text.toString().ifBlank { "🐱" }; r.phrases = p.text.toString().ifBlank { r.name + "!" }
                r.every = (s.text.toString().toIntOrNull() ?: 6).coerceIn(3, 60); r.on = true
                if (old == null) items.add(r)
                Store.save(this, items); Sched.set(this, r, Sched.next(r), false); draw()
            }
            .setNegativeButton(if (old != null) "Xoá" else "Huỷ") { _, _ ->
                if (old != null) { Sched.cancel(this, r); items.remove(r); Store.save(this, items); draw() }
            }.show()
    }
}
